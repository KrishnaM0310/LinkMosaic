import json, boto3, os
from io import BytesIO
from urllib.parse import unquote_plus
from pdfminer.high_level import extract_text

# Initialize clients
lambda_client = boto3.client("lambda")
s3 = boto3.client("s3")

def call_lambda(function_name, payload):
    """Invoke another Lambda synchronously and return parsed response."""
    response = lambda_client.invoke(
        FunctionName=function_name,
        InvocationType="RequestResponse",
        Payload=json.dumps(payload)
    )
    return json.loads(response["Payload"].read())

def get_text_from_s3(event):
    """Extract text from PDF or TXT file uploaded to S3."""
    record = event["Records"][0]
    bucket = record["s3"]["bucket"]["name"]
    key = unquote_plus(record["s3"]["object"]["key"])
    obj = s3.get_object(Bucket=bucket, Key=key)
    body = obj["Body"].read()

    if key.lower().endswith(".pdf"):
        return extract_text(BytesIO(body))
    elif key.lower().endswith(".txt"):
        return body.decode("utf-8")
    else:
        return ""

def handler(event, _):
    # 🔹 Step 0: Extract text if triggered by S3
    if "Records" in event:  # S3 event trigger
        text_input = get_text_from_s3(event)
    else:
        text_input = event["inputs"]["text"]

    # 1️⃣ Summarize
    summaries_resp = call_lambda("LinkMosaic_SummaryExtractor", {"inputs": {"text": text_input}})
    summaries = summaries_resp.get("summary", "")
    print("Summaries:", summaries)

    # 2️⃣ Get embeddings
    emb_resp = call_lambda("LinkMosaic_EmbeddingTool", {"inputs": {"texts": [summaries]}})
    embeddings = emb_resp.get("embeddings", [])
    print("Embeddings:", embeddings)

    # 3️⃣ Cluster
    cluster_resp = call_lambda("LinkMosaic_ClusterTool", {"inputs": {"embeddings": embeddings}})
    clusters = cluster_resp.get("clusters", [])
    print("Clusters:", clusters)

    # 4️⃣ Infer relationships
    rel_resp = call_lambda("LinkMosaic_RelationshipInfer", {"inputs": {"summaries": [summaries]}})
    edges = rel_resp.get("edges", [])
    print("Edges:", edges)

    # 5️⃣ Build map
    map_resp = call_lambda("LinkMosaic_MapBuilder", {
        "inputs": {
            "summaries": [summaries],
            "clusters": clusters,
            "edges": edges
        }
    })

    return {
        "status": "ok",
        "map_output": map_resp
    }

